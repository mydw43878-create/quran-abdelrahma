import 'dart:io';
import 'dart:typed_data';

import 'package:audioplayers/audioplayers.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const QuranApp());
}

const Color deepGreen = Color(0xFF092B25);
const Color cardGreen = Color(0xFF123B32);
const Color gold = Color(0xFFD8B56D);
const Color softWhite = Color(0xFFF7F3E9);

class Surah {
  final int number;
  final String name;
  final int verses;
  const Surah(this.number, this.name, this.verses);
}

const List<Surah> surahs = [
  Surah(1, 'الفاتحة', 7), Surah(2, 'البقرة', 286),
  Surah(3, 'آل عمران', 200), Surah(4, 'النساء', 176),
  Surah(5, 'المائدة', 120), Surah(6, 'الأنعام', 165),
  Surah(7, 'الأعراف', 206), Surah(8, 'الأنفال', 75),
  Surah(9, 'التوبة', 129), Surah(10, 'يونس', 109),
  Surah(11, 'هود', 123), Surah(12, 'يوسف', 111),
  Surah(13, 'الرعد', 43), Surah(14, 'إبراهيم', 52),
  Surah(15, 'الحجر', 99), Surah(16, 'النحل', 128),
  Surah(17, 'الإسراء', 111), Surah(18, 'الكهف', 110),
  Surah(19, 'مريم', 98), Surah(20, 'طه', 135),
  Surah(21, 'الأنبياء', 112), Surah(22, 'الحج', 78),
  Surah(23, 'المؤمنون', 118), Surah(24, 'النور', 64),
  Surah(25, 'الفرقان', 77), Surah(26, 'الشعراء', 227),
  Surah(27, 'النمل', 93), Surah(28, 'القصص', 88),
  Surah(29, 'العنكبوت', 69), Surah(30, 'الروم', 60),
  Surah(31, 'لقمان', 34), Surah(32, 'السجدة', 30),
  Surah(33, 'الأحزاب', 73), Surah(34, 'سبأ', 54),
  Surah(35, 'فاطر', 45), Surah(36, 'يس', 83),
  Surah(37, 'الصافات', 182), Surah(38, 'ص', 88),
  Surah(39, 'الزمر', 75), Surah(40, 'غافر', 85),
  Surah(41, 'فصلت', 54), Surah(42, 'الشورى', 53),
  Surah(43, 'الزخرف', 89), Surah(44, 'الدخان', 59),
  Surah(45, 'الجاثية', 37), Surah(46, 'الأحقاف', 35),
  Surah(47, 'محمد', 38), Surah(48, 'الفتح', 29),
  Surah(49, 'الحجرات', 18), Surah(50, 'ق', 45),
  Surah(51, 'الذاريات', 60), Surah(52, 'الطور', 49),
  Surah(53, 'النجم', 62), Surah(54, 'القمر', 55),
  Surah(55, 'الرحمن', 78), Surah(56, 'الواقعة', 96),
  Surah(57, 'الحديد', 29), Surah(58, 'المجادلة', 22),
  Surah(59, 'الحشر', 24), Surah(60, 'الممتحنة', 13),
  Surah(61, 'الصف', 14), Surah(62, 'الجمعة', 11),
  Surah(63, 'المنافقون', 11), Surah(64, 'التغابن', 18),
  Surah(65, 'الطلاق', 12), Surah(66, 'التحريم', 12),
  Surah(67, 'الملك', 30), Surah(68, 'القلم', 52),
  Surah(69, 'الحاقة', 52), Surah(70, 'المعارج', 44),
  Surah(71, 'نوح', 28), Surah(72, 'الجن', 28),
  Surah(73, 'المزمل', 20), Surah(74, 'المدثر', 56),
  Surah(75, 'القيامة', 40), Surah(76, 'الإنسان', 31),
  Surah(77, 'المرسلات', 50), Surah(78, 'النبأ', 40),
  Surah(79, 'النازعات', 46), Surah(80, 'عبس', 42),
  Surah(81, 'التكوير', 29), Surah(82, 'الانفطار', 19),
  Surah(83, 'المطففين', 36), Surah(84, 'الانشقاق', 25),
  Surah(85, 'البروج', 22), Surah(86, 'الطارق', 17),
  Surah(87, 'الأعلى', 19), Surah(88, 'الغاشية', 26),
  Surah(89, 'الفجر', 30), Surah(90, 'البلد', 20),
  Surah(91, 'الشمس', 15), Surah(92, 'الليل', 21),
  Surah(93, 'الضحى', 11), Surah(94, 'الشرح', 8),
  Surah(95, 'التين', 8), Surah(96, 'العلق', 19),
  Surah(97, 'القدر', 5), Surah(98, 'البينة', 8),
  Surah(99, 'الزلزلة', 8), Surah(100, 'العاديات', 11),
  Surah(101, 'القارعة', 11), Surah(102, 'التكاثر', 8),
  Surah(103, 'العصر', 3), Surah(104, 'الهمزة', 9),
  Surah(105, 'الفيل', 5), Surah(106, 'قريش', 4),
  Surah(107, 'الماعون', 7), Surah(108, 'الكوثر', 3),
  Surah(109, 'الكافرون', 6), Surah(110, 'النصر', 3),
  Surah(111, 'المسد', 5), Surah(112, 'الإخلاص', 4),
  Surah(113, 'الفلق', 5), Surah(114, 'الناس', 6),
];

class QuranApp extends StatelessWidget {
  const QuranApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'القرآن بصوت عبد الرحمن',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: deepGreen,
        colorScheme: ColorScheme.fromSeed(seedColor: gold, brightness: Brightness.dark),
        fontFamily: 'Roboto',
      ),
      home: const QuranHomePage(),
    );
  }
}

class QuranHomePage extends StatefulWidget {
  const QuranHomePage({super.key});

  @override
  State<QuranHomePage> createState() => _QuranHomePageState();
}

class _QuranHomePageState extends State<QuranHomePage> {
  final AudioPlayer _player = AudioPlayer();
  final TextEditingController _search = TextEditingController();
  final Map<int, String> _recordings = {};
  int? _currentSurah;
  String? _currentPath;
  PlayerState _playerState = PlayerState.stopped;
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadRecordings();
    _player.onPositionChanged.listen((p) {
      if (mounted) setState(() => _position = p);
    });
    _player.onDurationChanged.listen((d) {
      if (mounted) setState(() => _duration = d);
    });
    _player.onPlayerStateChanged.listen((s) {
      if (mounted) setState(() => _playerState = s);
    });
    _player.onPlayerComplete.listen((_) {
      if (mounted) setState(() {
        _position = Duration.zero;
        _playerState = PlayerState.completed;
      });
    });
  }

  Future<void> _loadRecordings() async {
    final prefs = await SharedPreferences.getInstance();
    for (final s in surahs) {
      final path = prefs.getString('audio_${s.number}');
      if (path != null && await File(path).exists()) {
        _recordings[s.number] = path;
      }
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _savePath(int number, String path) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('audio_$number', path);
    if (!mounted) return;
    setState(() => _recordings[number] = path);
  }

  Future<void> _addAudio(Surah surah) async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.audio,
        allowMultiple: false,
        withData: true,
      );
      if (result == null || result.files.isEmpty) return;
      final picked = result.files.single;
      final Uint8List? bytes = picked.bytes;
      if (bytes == null) {
        _message('تعذر قراءة الملف. جرّب اختيار ملف صوتي آخر.');
        return;
      }
      final dir = await getApplicationDocumentsDirectory();
      final audioDir = Directory('${dir.path}/my_quran_audio');
      if (!await audioDir.exists()) await audioDir.create(recursive: true);
      final safeName = picked.name.replaceAll(RegExp(r'[^a-zA-Z0-9._-]'), '_');
      final target = File('${audioDir.path}/surah_${surah.number}_$safeName');
      await target.writeAsBytes(bytes, flush: true);
      await _savePath(surah.number, target.path);
      _message('تمت إضافة تسجيل سورة ${surah.name} بنجاح');
    } catch (e) {
      _message('حصلت مشكلة أثناء إضافة الملف: $e');
    }
  }

  Future<void> _removeAudio(Surah surah) async {
    final path = _recordings[surah.number];
    if (path != null) {
      try {
        final file = File(path);
        if (await file.exists()) await file.delete();
      } catch (_) {}
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('audio_${surah.number}');
    if (_currentSurah == surah.number) {
      await _player.stop();
      setState(() {
        _currentSurah = null;
        _currentPath = null;
        _position = Duration.zero;
        _duration = Duration.zero;
      });
    }
    if (mounted) setState(() => _recordings.remove(surah.number));
  }

  Future<void> _playSurah(Surah surah) async {
    final path = _recordings[surah.number];
    if (path == null) {
      _message('أضف تسجيلك لهذه السورة أولاً');
      return;
    }
    try {
      if (_currentSurah == surah.number && _playerState == PlayerState.playing) {
        await _player.pause();
      } else if (_currentSurah == surah.number && _playerState == PlayerState.paused) {
        await _player.resume();
      } else {
        await _player.stop();
        setState(() {
          _currentSurah = surah.number;
          _currentPath = path;
          _position = Duration.zero;
          _duration = Duration.zero;
        });
        await _player.play(DeviceFileSource(path));
      }
    } catch (e) {
      _message('تعذر تشغيل التسجيل. قد يكون الملف نُقل أو حُذف.');
    }
  }

  Future<void> _togglePlayback() async {
    if (_currentPath == null) return;
    if (_playerState == PlayerState.playing) {
      await _player.pause();
    } else if (_playerState == PlayerState.paused) {
      await _player.resume();
    } else {
      final s = surahs.firstWhere((x) => x.number == _currentSurah);
      await _playSurah(s);
    }
  }

  void _message(String value) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(value, textAlign: TextAlign.right), backgroundColor: cardGreen),
    );
  }

  String _time(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  void dispose() {
    _search.dispose();
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final query = _search.text.trim();
    final filtered = surahs.where((s) =>
      query.isEmpty || s.name.contains(query) || s.number.toString() == query
    ).toList();
    final count = _recordings.length;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SafeArea(
          child: Column(
            children: [
              _header(count),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 8, 18, 12),
                child: TextField(
                  controller: _search,
                  onChanged: (_) => setState(() {}),
                  textAlign: TextAlign.right,
                  decoration: InputDecoration(
                    hintText: 'ابحث عن سورة...',
                    prefixIcon: const Icon(Icons.search, color: gold),
                    filled: true,
                    fillColor: cardGreen,
                    contentPadding: const EdgeInsets.symmetric(vertical: 14),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                  ),
                ),
              ),
              Expanded(
                child: _loading
                  ? const Center(child: CircularProgressIndicator(color: gold))
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                      itemCount: filtered.length,
                      itemBuilder: (context, index) {
                        final s = filtered[index];
                        final hasAudio = _recordings.containsKey(s.number);
                        final active = _currentSurah == s.number;
                        return Container(
                          margin: const EdgeInsets.only(bottom: 9),
                          decoration: BoxDecoration(
                            color: active ? const Color(0xFF1B4A3E) : cardGreen,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: active ? gold.withOpacity(.65) : Colors.white10),
                          ),
                          child: ListTile(
                            contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                            leading: Container(
                              width: 42, height: 42,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(color: gold.withOpacity(.7)),
                              ),
                              child: Center(child: Text('${s.number}', style: const TextStyle(color: gold, fontWeight: FontWeight.bold))),
                            ),
                            title: Text(s.name, style: const TextStyle(color: softWhite, fontSize: 17, fontWeight: FontWeight.w600)),
                            subtitle: Text('${s.verses} آية  •  ${hasAudio ? 'تمت إضافة صوتك' : 'لم تضف تسجيلاً بعد'}',
                              style: TextStyle(color: hasAudio ? gold : Colors.white60, fontSize: 12)),
                            trailing: Wrap(
                              spacing: 0,
                              children: [
                                IconButton(
                                  tooltip: hasAudio ? 'تشغيل التسجيل' : 'أضف تسجيل',
                                  onPressed: () => hasAudio ? _playSurah(s) : _addAudio(s),
                                  icon: Icon(
                                    hasAudio ? (active && _playerState == PlayerState.playing ? Icons.pause_circle_filled : Icons.play_circle_fill) : Icons.add_circle_outline,
                                    color: gold, size: 29,
                                  ),
                                ),
                                PopupMenuButton<String>(
                                  icon: const Icon(Icons.more_vert, color: Colors.white70),
                                  color: cardGreen,
                                  onSelected: (v) {
                                    if (v == 'add') _addAudio(s);
                                    if (v == 'delete') _removeAudio(s);
                                  },
                                  itemBuilder: (_) => [
                                    PopupMenuItem(value: 'add', child: Text(hasAudio ? 'استبدال التسجيل' : 'إضافة تسجيل', style: const TextStyle(color: softWhite))),
                                    if (hasAudio) const PopupMenuItem(value: 'delete', child: Text('حذف التسجيل', style: TextStyle(color: Colors.redAccent))),
                                  ],
                                ),
                              ],
                            ),
                            onTap: () => hasAudio ? _playSurah(s) : _addAudio(s),
                          ),
                        );
                      },
                    ),
              ),
              if (_currentSurah != null) _playerPanel(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _header(int count) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(22, 22, 22, 20),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF17483B), deepGreen],
          begin: Alignment.topRight, end: Alignment.bottomLeft,
        ),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const [
              Icon(Icons.auto_awesome, color: gold, size: 19),
              SizedBox(width: 8),
              Text('القرآن الكريم', style: TextStyle(color: gold, fontSize: 15)),
              SizedBox(width: 8),
              Icon(Icons.auto_awesome, color: gold, size: 19),
            ],
          ),
          const SizedBox(height: 8),
          const Text('بصوت عبد الرحمن', style: TextStyle(color: softWhite, fontSize: 27, fontWeight: FontWeight.bold)),
          const SizedBox(height: 7),
          const Text('مساحتك الخاصة للاستماع إلى تلاواتك', style: TextStyle(color: Colors.white70, fontSize: 13)),
          const SizedBox(height: 17),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _stat('114', 'سورة'),
              Container(width: 1, height: 30, color: Colors.white24, margin: const EdgeInsets.symmetric(horizontal: 28)),
              _stat('${surahs.length == 0 ? 0 : _recordings.length}', 'تسجيل مضاف'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _stat(String value, String label) => Column(
    children: [
      Text(value, style: const TextStyle(color: gold, fontWeight: FontWeight.bold, fontSize: 20)),
      Text(label, style: const TextStyle(color: Colors.white70, fontSize: 11)),
    ],
  );

  Widget _playerPanel() {
    final current = surahs.firstWhere((s) => s.number == _currentSurah);
    final maxMs = _duration.inMilliseconds > 0 ? _duration.inMilliseconds.toDouble() : 1.0;
    final value = _position.inMilliseconds.clamp(0, maxMs.toInt()).toDouble();
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 16),
      decoration: const BoxDecoration(
        color: Color(0xFF061F1B),
        border: Border(top: BorderSide(color: gold, width: .5)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              const Icon(Icons.graphic_eq, color: gold),
              const SizedBox(width: 10),
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('سورة ${current.name}', style: const TextStyle(color: softWhite, fontWeight: FontWeight.bold)),
                  const Text('تلاوة عبد الرحمن', style: TextStyle(color: Colors.white60, fontSize: 11)),
                ],
              )),
              IconButton(onPressed: () async { await _player.stop(); setState(() { _currentSurah = null; _currentPath = null; }); },
                icon: const Icon(Icons.close, color: Colors.white70)),
            ],
          ),
          Slider(
            value: value,
            max: maxMs,
            activeColor: gold,
            inactiveColor: Colors.white24,
            onChanged: _duration == Duration.zero ? null : (v) => _player.seek(Duration(milliseconds: v.round())),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(_time(_position), style: const TextStyle(color: Colors.white60, fontSize: 11)),
              IconButton(
                onPressed: _togglePlayback,
                iconSize: 42,
                color: gold,
                icon: Icon(_playerState == PlayerState.playing ? Icons.pause_circle_filled : Icons.play_circle_fill),
              ),
              Text(_time(_duration), style: const TextStyle(color: Colors.white60, fontSize: 11)),
            ],
          ),
        ],
      ),
    );
  }
}
